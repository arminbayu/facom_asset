Kalo mau update assert app pastikan nama dan tipe file harus sama,
ubah versi dengan menambah angka paling belakang